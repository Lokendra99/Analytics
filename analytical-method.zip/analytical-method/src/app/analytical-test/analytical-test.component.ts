import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-analytical-test',
  templateUrl: './analytical-test.component.html',
  styleUrls: ['./analytical-test.component.css']
})
export class AnalyticalTestComponent implements OnInit {
    public submitted = false;
    public showRelatedSwabParams = false;
    public showRelatedRinseParams = false;

    public showRelatedMocForm = false;
    public validateForm: FormGroup;

    public residueTypes = [{ id: 'AXC101', key: 'API' },
                          { id: 'AXC102', key: 'Cleaning Agent'},
                          { id: 'AXC103', key: 'Bioburden' },
                          { id: 'AXC104', key: 'Endotoxin'}];
    public model = {};

    constructor(private formBuilder: FormBuilder) { }

    ngOnInit() {
        this.validateForm = this.formBuilder.group({
            id: ['', Validators.required],
            targetResidueType: ['', Validators.required],
            reasonParameters: ['', Validators.required],
            LOD: ['',  Validators.min(1)],
            LOQ: ['',  Validators.min(1)],
            TNTC: ['',  Validators.min(1)],
            TFTC: ['',  Validators.min(1)],
        });
    }

    get remove() { return JSON.stringify(this.model); }

    getDataForResidueType(residueTypeUserVal: string) {
        this.showRelatedSwabParams = false;
        const self = this;
        this.residueTypes.forEach(function (residueType) {
            if (residueType.key === residueTypeUserVal) {
                self.model['id'] = residueType['id'];
            }
        });
    }

    addUpdateBasicField(ev) {
        if (ev['value'] !== null) {
            this.model[ev['fieldName']] = ev['value'];
        } else {
            delete this.model[ev['fieldName']];
        }

    }
    get reasonParameters() { return this.validateForm.get('reasonParameters'); }
    onSubmit() {
        console.log('Result+++', this.model)
        for (const key in this.model) {
            localStorage.setItem(key, this.model[key])

        }
    }
}

