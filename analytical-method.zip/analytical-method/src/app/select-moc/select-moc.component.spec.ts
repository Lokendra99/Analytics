import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectMocComponent } from './select-moc.component';

describe('SelectMocComponent', () => {
  let component: SelectMocComponent;
  let fixture: ComponentFixture<SelectMocComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelectMocComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectMocComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
