import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-select-moc',
  templateUrl: './select-moc.component.html',
  styleUrls: ['./select-moc.component.css']
})
export class SelectMocComponent implements OnInit {
   
    public mocs = [];
    public mocListVal = ['Stainless Steel', 'Glass', 'Teflon', 'Plastic'];
    public savedNewMoc = [];
    public userMocs = [];
    public dataToEmit = { fieldName: 'MOC', value: [] };
    public newMoc = {
        MocList: this.mocListVal,
        Recovery: ''
    };
    public model = {
        mocType: [],
        newMocRecovery: []
    };
    
    @Input() moc: object;
    @Output() userValForSpecificFieldCheck: EventEmitter<any> = new EventEmitter();

    constructor() { }

    ngOnInit() {
    }
    addMOC(ndx) {
        this.savedNewMoc[ndx] = false;
        this.mocs.push(this.newMoc);
    }

    addnewMocData(ndx) {
        this.savedNewMoc[ndx] = true;
        const index = this.userMocs.findIndex(obj => obj['MOC TYPE'] === this.model['mocType']);
        if (index >- 1) {
            this.userMocs[index]['Recovery'] = this.model['newMocRecovery'];
        } else {
            this.userMocs.push({
                'MOC Type': this.model['mocType'][ndx],
                'Recovery': this.model['newMocRecovery'][ndx]
            });
        }
        this.userValForSpecificFieldCheck.emit(this.userMocs);
    }
    removeExistingMocData(ndx) {
        this.userMocs.splice(ndx, 1);
        this.mocs.splice(ndx, 1);
        this.userValForSpecificFieldCheck.emit(this.userMocs);

    }
}
