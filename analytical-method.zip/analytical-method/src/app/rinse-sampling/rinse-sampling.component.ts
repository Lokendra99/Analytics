import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-rinse-sampling',
  templateUrl: './rinse-sampling.component.html',
  styleUrls: ['./rinse-sampling.component.css']
})
export class RinseSamplingComponent implements OnInit {
    public model = {};
    @Input() targetResidueType: string;
    @Input() showRelatedRinseParams: boolean;
    public dataToEmit = { fieldName: 'rinseParams', value: {} };
    @Output() userValForSpecificField: EventEmitter<any> = new EventEmitter();


    constructor() { }

    ngOnInit() {
    }
   
    changeOfUserVal(ev, subfieldName) {
        this.dataToEmit['value'][subfieldName] = ev;
        this.userValForSpecificField.emit(
            this.dataToEmit
        );
    }
    removeRinseParams() {
        this.showRelatedRinseParams = false;
        this.model['swabMethodUsed'] = '';
        this.model['defaultRecovery'] = '';
        this.dataToEmit = { fieldName: 'rinseParams', value: null };
        this.userValForSpecificField.emit(
            this.dataToEmit
        );
    }

}
