import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RinseSamplingComponent } from './rinse-sampling.component';

describe('RinseSamplingComponent', () => {
  let component: RinseSamplingComponent;
  let fixture: ComponentFixture<RinseSamplingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RinseSamplingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RinseSamplingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
