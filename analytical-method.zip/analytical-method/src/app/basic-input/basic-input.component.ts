import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-basic-input',
  templateUrl: './basic-input.component.html',
  styleUrls: ['./basic-input.component.css']
})
export class BasicInputComponent implements OnInit {
    public model = {};
    public showTNTCandTFTC = false;
    @Input() targetResidueType: string;
    @Input() validateForm: FormGroup;

    
    @Output() userValForSpecificField: EventEmitter<any> = new EventEmitter();

  constructor() { }

  ngOnInit() {
  }
    changeOfUserVal(ev, fieldName) {
        this.userValForSpecificField.emit({
            fieldName: fieldName,
            value: ev
        });
    }
    get LOD() { return this.validateForm.get('LOD'); }
    get LOQ() { return this.validateForm.get('LOQ'); }
    get TNTC() { return this.validateForm.get('TNTC'); }
    get TFTC() { return this.validateForm.get('TFTC'); }



    onSpecifyingChoices(choice: number) {
        if (choice) {
            this.showTNTCandTFTC = true;
        } else {
            this.showTNTCandTFTC = false;
        }
    }

}
