import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AnalyticalTestComponent } from './analytical-test/analytical-test.component';
import { SelectMocComponent } from './select-moc/select-moc.component';
import { SwabSamplingComponent } from './swab-sampling/swab-sampling.component';
import { BasicInputComponent } from './basic-input/basic-input.component';
import { RinseSamplingComponent } from './rinse-sampling/rinse-sampling.component';

@NgModule({
  declarations: [
    AppComponent,
    AnalyticalTestComponent,
    SelectMocComponent,
    SwabSamplingComponent,
    BasicInputComponent,
    RinseSamplingComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
