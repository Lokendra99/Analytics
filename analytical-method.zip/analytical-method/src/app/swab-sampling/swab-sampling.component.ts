import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-swab-sampling',
  templateUrl: './swab-sampling.component.html',
  styleUrls: ['./swab-sampling.component.css']
})
export class SwabSamplingComponent implements OnInit {

    public model = {};
    public dataToEmit = {};

    @Input() targetResidueType: string;
    @Input() showRelatedSwabParams: boolean;
    @Output() userValForSpecificField: EventEmitter<any> = new EventEmitter();

    constructor() { }

    ngOnInit() {
         this.dataToEmit = { fieldName: 'swabParams', value: {} };

    }


    changeOfUserVal(ev, subfieldName) {

        this.dataToEmit['value'][subfieldName] = ev;

        this.userValForSpecificField.emit(
            this.dataToEmit
        );
    }
    removeSwabParams() {
        this.showRelatedSwabParams = false;
        this.model['swabMethodUsed'] = '';
        this.model['solventName'] = '';
        this.model['solventQuantity'] = '';
        this.model['defaultRecovery'] = '';
        this.dataToEmit = { fieldName: 'swabParams', value: null };
        this.userValForSpecificField.emit(
            this.dataToEmit
        );


    }

}
