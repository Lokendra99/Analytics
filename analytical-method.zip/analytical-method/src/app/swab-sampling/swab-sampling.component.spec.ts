import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SwabSamplingComponent } from './swab-sampling.component';

describe('SwabSamplingComponent', () => {
  let component: SwabSamplingComponent;
  let fixture: ComponentFixture<SwabSamplingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SwabSamplingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SwabSamplingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
